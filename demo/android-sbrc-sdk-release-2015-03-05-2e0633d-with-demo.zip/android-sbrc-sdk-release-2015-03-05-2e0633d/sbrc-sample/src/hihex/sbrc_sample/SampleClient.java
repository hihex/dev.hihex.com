package hihex.sbrc_sample;

import hihex.sbrc.AvatarRequest;
import hihex.sbrc.Client;
import hihex.sbrc.DisconnectReason;
import hihex.sbrc.Identity;
import hihex.sbrc.SbrcManager;
import hihex.sbrc.ShareRequest;
import hihex.sbrc.ShareType;
import hihex.sbrc.events.PanEvent;
import hihex.sbrc.events.PanState;
import hihex.sbrc.events.TapEvent;

import java.io.IOException;
import java.io.InputStream;
import java.util.Scanner;

import android.animation.ObjectAnimator;
import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.Toast;

public class SampleClient extends Client {
    private final FrameLayout mParent;
    private final View mView;
    private final FrameLayout.LayoutParams mLayoutParams;
    private final Activity mContext;
    private static String sShareMessageTemplate;
    private String mMyName;

    public SampleClient(final Activity context, final FrameLayout layout) {
        mParent = layout;
        mContext = context;
        mView = new View(context);
        mView.setBackgroundColor(Color.RED);
        mLayoutParams = new FrameLayout.LayoutParams(50, 50);
    }

    @Override
    public void onConnect(final Identity identity) {
        mContext.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                mLayoutParams.topMargin = 100;
                mLayoutParams.leftMargin = 400;
                mParent.addView(mView, mLayoutParams);
            }
        });
        onIdentityUpdated(null, identity);
    }

    @Override
    public void onDisconnect(final Identity identity, final DisconnectReason reason) {
        mContext.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(mContext, "Goodbye, " + identity.nickname, Toast.LENGTH_SHORT).show();
                mParent.removeView(mView);
            }
        });
    }

    @Override
    public void onIdentityUpdated(final Identity oldIdentity, final Identity newIdentity) {
        mContext.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(mContext, "Hello, " + newIdentity.nickname, Toast.LENGTH_SHORT).show();
            }
        });
        mMyName = newIdentity.nickname;

        // Request for the user's avatar. 
        SbrcManager.instance.request(newIdentity.deviceId, new AvatarRequest(50, 50, 15) {
            @Override
            protected void onResult(final int errorCode, final byte[] iconData) {
                // Show the user's avatar.
                mContext.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        final Bitmap bitmap = BitmapFactory.decodeByteArray(iconData, 0, iconData.length);
                        final BitmapDrawable drawable = new BitmapDrawable(mContext.getResources(), bitmap);
                        mView.setBackground(drawable);
                    }
                });
            }
        });
    }

    // This method is called when we retrieve the "pan" event. 
    // Check the class structure of `Client` to see all supported events.
    @Override
    public void onPan(final PanEvent event) {
        // Move the view.
        if (event.state != PanState.kBegin) {
            final float dx = event.dx;
            final float dy = event.dy;
            mContext.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    mLayoutParams.leftMargin += dx;
                    mLayoutParams.topMargin += dy;
                    mView.setLayoutParams(mLayoutParams);
                }
            });

        }
    }

    // This method is called when we retrieve the "tap" event. 
    @Override
    public void onTap(final TapEvent event) {
        // Rotate the view by 360 degrees.
        mContext.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                final ObjectAnimator animator = ObjectAnimator.ofFloat(mView, View.ROTATION, 0, 360);
                animator.start();
            }
        });

        // Request the client to share a message if we tapped too many times.
        // The image will be generated from an HTML page. The image's size will be set to 380x240.
        if (event.tapsCount == 3) {
            if (sShareMessageTemplate == null) {
                initShareMessageTemplate(mContext);
            }
            final String message = String.format(sShareMessageTemplate, mMyName);
            SbrcManager.instance.request(event.deviceId, new ShareRequest(ShareType.kHtmlImage, message, 380, 240) {
                @Override
                protected void onResult(final int errorCode, final Void ignored) {
                    mContext.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(mContext, "Share result: " + errorCode, Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            });
        }
    }

    // Read the entire HTML file in an asset into a string.
    private static void initShareMessageTemplate(final Context context) {
        InputStream shareMessageFile = null;
        try {
            shareMessageFile = context.getAssets().open("Share.html");
            // To avoid having too much dependency in this project we use the trick in http://stackoverflow.com/a/5445161/
            // to read the file into a string. In practise, you should use dedicated functions like IOUtils.toString() 
            // from Apache Commons instead.
            final Scanner scanner = new Scanner(shareMessageFile);
            scanner.useDelimiter("\\A");
            sShareMessageTemplate = scanner.next();
        } catch (final IOException e) {
            e.printStackTrace();
        } finally {
            if (shareMessageFile != null) {
                try {
                    shareMessageFile.close();
                } catch (final IOException e) {}
            }
        }
    }
}
