package hihex.sbrc_sample;

import hihex.sbrc.Client;
import hihex.sbrc.ClientFactory;
import hihex.sbrc.SbrcManager;

import java.io.ByteArrayOutputStream;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.widget.FrameLayout;

public class SbrcSampleActivity extends Activity {
    private FrameLayout mLayout;

    @Override
    public void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mLayout = new FrameLayout(this);
        mLayout.setBackgroundColor(0xffdddddd);
        setContentView(mLayout);

        // SBRC Specific: Initialize the server on start.
        SbrcManager.instance.initialize(this);

        initGame();
    }

    // SBRC Specific: Terminate the server on stop.
    @Override
    public void onDestroy() {
        super.onDestroy();
        SbrcManager.instance.destroy(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        SbrcManager.instance.pause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        SbrcManager.instance.resume();
    }

    private void initGame() {
        final SbrcManager manager = SbrcManager.instance;

        // Let the clients know our game.
        manager.setIcon(fetchGameIcon());

        // Set the client factory. This is used to generate clients for receiving events (see also SampleClient.java.)
        manager.setClientFactory(new ClientFactory() {
            @Override
            public Client create() {
                //return new SampleClient(SbrcSampleActivity.this, mLayout);
                return new SampleStandardClient(SbrcSampleActivity.this, mLayout);
            }
        });

        // Some method requires a fully-initialized manager (otherwise they will throw NullPointerException). Wrap these
        // in `runWhenReady()` to ensure such state.
        /*
        manager.runWhenReady(new Runnable() {
            @Override
            public void run() {
                // ...
            }
        });
        */
    }

    private byte[] fetchGameIcon() {
        final Drawable drawable = getResources().getDrawable(R.drawable.ic_launcher);
        if (!(drawable instanceof BitmapDrawable)) {
            Log.e("SBRCSample", "Something's wrong -- ic_launcher.png does not give us a BitmapDrawable?");
            return null;
        }
        final Bitmap bitmap = ((BitmapDrawable) drawable).getBitmap();
        final ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 0, stream);
        final byte[] icon = stream.toByteArray();
        if (icon.length >= 32768) {
            Log.e("SBRCSample", "The icon is larger than 32 KB.");
            return null;
        }
        return icon;
    }
}
