Requirement
-----------

* Target: Android 4.1 or above, in x86 or ARMv7.
* IDE: Eclipse with ADT 22.3 or above

Standard Installation
---------------------

1. Copy everything in the `libs/` folder to the `libs/` folder of your project.
2. Copy everything in the `res/` folder to the `res/` folder of your project.
3. Refresh and start to use.

Using Miniservices
------------------

The standard installation requires the HexLink Helper installed on the TV to
work. If you prefer to avoid this external dependency, you could opt for the
built-in "miniservice" instead. To enable it,

1. Add the following permissions under the `<manifest>` tag to
   AndroidManifest.xml:

        <uses-permission android:name="android.permission.INTERNET" android:required="true"/>
        <uses-permission android:name="android.permission.ACCESS_WIFI_STATE" android:required="true"/>
        <uses-permission android:name="android.permission.CHANGE_WIFI_MULTICAST_STATE" android:required="true"/>
        <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" android:required="true"/>

2. Add the following service and activity to under the `<application>` tag to
   AndroidManifest.xml:

        <service android:exported="false" android:name="hihex.sbrc.miniservices.SbrcService">
            <intent-filter>
                <action android:name="hihex.sbrc.services.SbrcService"/>
                <category android:name="hihex.sbrc.services.SbrcService"/>
            </intent-filter>
        </service>
        <activity android:name="hihex.sbrc.miniservices.PaymentWindowActivity"
                  android:theme="@android:style/Theme.Translucent.NoTitleBar.Fullscreen"/>

3. If you want to enable obfuscation, please ensure the following members are
   kept:

        -keepclassmembers class hihex.sbrc.miniservices.BaseServiceNative {
            void report*(...);
            native <methods>;
        }
        -keep class hihex.sbrc.client.InstallProgress { *; }
        -keep class hihex.sbrc.Identity { *; }
        -keep class hihex.sbrc.client.AppInfo { *; }
        -keep enum hihex.sbrc.client.MediaStatus { *; }


