需求
----

* 編譯目標：Android 4.1 或以上，使用 x86 或 ARMv7（不支援MIPS）。
* IDE: Eclipse 及 ADT 22.3 或以上。

標準安裝
--------

1. 將所有「libs/」資料夾下的檔案複製至專案的「libs/」資料夾下。
2. 將所有「res/」資料夾下的檔案也複製至專案的「res/」資料夾下。
3. 重新整理後即可使用。

使用「內置服務」
--------------

「標準安裝」方案必須配合電視上的「好連遙控後台服務」才有效。若不想要這額外程式，可以使用 SDK 的「內置服務」代替。啟動方法為：

1. 將以下代碼加到 AndroidManifest.xml 的 `<manifest>` 標籤之下：

        <uses-permission android:name="android.permission.INTERNET" android:required="true"/>
        <uses-permission android:name="android.permission.ACCESS_WIFI_STATE" android:required="true"/>
        <uses-permission android:name="android.permission.CHANGE_WIFI_MULTICAST_STATE" android:required="true"/>
        <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" android:required="true"/>

2. 將以下代碼加到 AndroidManifest.xml 的 `<application>` 標籤之下：

        <service android:exported="false" android:name="hihex.sbrc.miniservices.SbrcService">
            <intent-filter>
                <action android:name="hihex.sbrc.services.SbrcService"/>
                <category android:name="hihex.sbrc.services.SbrcService"/>
            </intent-filter>
        </service>
        <activity android:name="hihex.sbrc.miniservices.PaymentWindowActivity"
                  android:theme="@android:style/Theme.Translucent.NoTitleBar.Fullscreen"/>

3. 如需要代碼混淆，請確保以下類別完好：

        -keepclassmembers class hihex.sbrc.miniservices.BaseServiceNative {
            void report*(...);
            native <methods>;
        }
        -keep class hihex.sbrc.client.InstallProgress { *; }
        -keep class hihex.sbrc.Identity { *; }
        -keep class hihex.sbrc.client.AppInfo { *; }
        -keep enum hihex.sbrc.client.MediaStatus { *; }



